<?php
set_time_limit(1800000000);
$fecha_generar=date('Y-m-d_H:i:s');

/** Incluir la libreria PHPExcel */
require_once 'Classes/PHPExcel.php';
//$persona_entidad=$_SESSION['entidad_persona'];
// Crea un nuevo objeto PHPExcel
$objPHPExcel = new PHPExcel();
//$objWorksheet = $objPHPExcel->getActiveSheet();

// Establecer propiedades
$objPHPExcel->getProperties()
->setCreator("Cattivo")
->setLastModifiedBy("Cattivo")
->setTitle("Certificados")
->setSubject("Certificados")
->setDescription("Certificados")
->setKeywords("Excel Office 2007 openxml php")
->setCategory("Certificados");

  $styleFuenteLetra = array(
    'font'  => array(
        'bold'  => true,
        'color' => array('rgb' => '000000'),
        'size'  => 9,
        'name'  => 'Verdana'
    ),
    'borders' => array(
      'allborders' => array(
          'style' => PHPExcel_Style_Border::BORDER_THIN,
          'color' => array('rgb' => '000000')
      )
    ),
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        'wrap' => true
    ),
    'fill' => array(
      'type' => PHPExcel_Style_Fill::FILL_SOLID,
      'color' => array('rgb' => '6284F7')
    )
  );
  $colorHoja=array(
    'fill' => array(
        'type' => PHPExcel_Style_Fill::FILL_SOLID,
        'color' => array('rgb' => 'CCD6F6')
    ),
    'borders' => array(
      'outline' => array(
        'style' => PHPExcel_Style_Border::BORDER_THIN,
        'color' => array('rgb' => '000000')
      )
    ),
    'alignment' => array(
      'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
      'wrap' => true
    )
  );
  
  $numero_registro=0;
  $numero_excel=0;
  $numero_ingresos=1;

  $objPHPExcel->getActiveSheet()->setTitle('Certificados');
 

  $sheet = $objPHPExcel->getActiveSheet();
  $sheet->getPageMargins()->setTop(0.6);
  $sheet->getPageMargins()->setBottom(0.6);
  $sheet->getPageMargins()->setHeader(0.4);
  $sheet->getPageMargins()->setFooter(0.4);
  $sheet->getPageMargins()->setLeft(0.4);
  $sheet->getPageMargins()->setRight(0.4);


// INICIO Filas titulos
  $objPHPExcel->setActiveSheetIndex($numero_registro)
  ->setCellValue('A1', '# CERTIFICADO')
  ->setCellValue('B1', 'F. EXPEDICIÓN')
  ->setCellValue('C1', 'VALOR')
  ->setCellValue('D1', 'CÓDIGO ACCIÓN')
  ->setCellValue('E1', 'ACTIVIDAD');




  $objPHPExcel->getActiveSheet($numero_registro)->getStyle('A1')->applyFromArray($styleFuenteLetra);
  $objPHPExcel->getActiveSheet($numero_registro)->getStyle('B1')->applyFromArray($styleFuenteLetra);
  $objPHPExcel->getActiveSheet($numero_registro)->getStyle('C1')->applyFromArray($styleFuenteLetra);
  $objPHPExcel->getActiveSheet($numero_registro)->getStyle('D1')->applyFromArray($styleFuenteLetra);
  $objPHPExcel->getActiveSheet($numero_registro)->getStyle('E1')->applyFromArray($styleFuenteLetra);
//inicio foreach

include('crud/rs/rprteSbstma.php');

$num_registro=2;
$id_registro=1;

$proyecto=$objRsrprteSbstma->RsProyecto();
if($proyecto){
  foreach($proyecto as $data_RsCertificados){
    $pro_codigo=$data_RsCertificados['pro_codigo'];
    $pro_referencia=$data_RsCertificados['pro_referencia'];
    $pro_descripcion=$data_RsCertificados['pro_descripcion'];

    $RsCertificados=$objRsrprteSbstma->RsCertificados($pro_codigo);
    if($RsCertificados){
      foreach ($RsCertificados as $data_RsCertificados){
        $act_codigo=$data_RsCertificados['act_codigo'];
        $act_referencia=$data_RsCertificados['act_referencia'];
        $act_descripcion=$data_RsCertificados['act_descripcion'];
        $act_fechaexpedicion=$data_RsCertificados['act_fechaexpedicion'];
        $act_certificado=$data_RsCertificados['act_certificado'];
        $aco_valor=$data_RsCertificados['aco_valor'];
        
    
        $objPHPExcel->setActiveSheetIndex($numero_registro)
        ->setCellValue('A'.$num_registro, $act_certificado)
        ->setCellValue('B'.$num_registro, substr($act_fechaexpedicion,0,10))
        ->setCellValueExplicit('C'.$num_registro, $aco_valor,PHPExcel_Cell_DataType::TYPE_NUMERIC)
        ->setCellValue('D'.$num_registro, $act_referencia)
        ->setCellValue('E'.$num_registro, $act_descripcion);

        $objPHPExcel->getActiveSheet($numero_registro)->getStyle('A'.$num_registro)->applyFromArray($colorHoja);
        $objPHPExcel->getActiveSheet($numero_registro)->getStyle('B'.$num_registro)->applyFromArray($colorHoja);
        $objPHPExcel->getActiveSheet($numero_registro)->getStyle('C'.$num_registro)->applyFromArray($colorHoja);
        $objPHPExcel->getActiveSheet($numero_registro)->getStyle('D'.$num_registro)->applyFromArray($colorHoja);
        $objPHPExcel->getActiveSheet($numero_registro)->getStyle('E'.$num_registro)->applyFromArray($colorHoja);


        $num_registro++;
        $id_registro++;
      }
      $num_registro=$num_registro;
    }
    
  }
}



// Fin de Registros //


 $objPHPExcel->getActiveSheet($numero_excel)->getColumnDimension('A')->setWidth(15);
 $objPHPExcel->getActiveSheet($numero_excel)->getColumnDimension('B')->setWidth(15);
 $objPHPExcel->getActiveSheet($numero_excel)->getColumnDimension('C')->setWidth(20);
 $objPHPExcel->getActiveSheet($numero_excel)->getColumnDimension('D')->setWidth(15);
 $objPHPExcel->getActiveSheet($numero_excel)->getColumnDimension('E')->setWidth(90);
 $objPHPExcel->getActiveSheet($numero_excel)->getRowDimension($numero_ingresos)->setRowHeight(30);



  // Establecer la hoja activa, para que cuando se abra el documento se muestre primero.
  $objPHPExcel->setActiveSheetIndex(0);



  // Se modifican los encabezados del HTTP para indicar que se envia un archivo de Excel.
  header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  header('Content-Disposition: attachment;filename="Certificados'.$fecha_generar.'.xlsx"');
  header('Cache-Control: max-age=0');
  $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
  // incluir o gráfico no ficheiro que vamos gerar
  $objWriter->setIncludeCharts(TRUE);
  ob_end_clean();
  $objWriter->save('php://output');
  exit;

?>
